
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.1/assets/img/favicons/favicon.ico">

    <title>Signin Template for Bootstrap</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
  </head>
    <body class="text-center">
      <nav class="navbar">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">WebSiteName</a>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <?php if(Auth::user()): ?>
            <li>
              <a href="<?php echo e(url('/')); ?>/logout"><span class="glyphicon glyphicon-user"></span> Logout</a>
            </li>
            <?php else: ?>
            <li>
              <a href="<?php echo e(url('/')); ?>/login"><span class="glyphicon glyphicon-user"></span> Employee Login</a>
            </li>
            <?php endif; ?>
           
          </ul>
        </div>
      </nav>
    
      <div class="container">
        <?php if(Auth::user()): ?>

        <?php if($isBreackTime =='yes'): ?>
          <button type="button" class="btn btn-primary" id="btnBack">Back</button>
          <?php else: ?>
          <button type="button" class="btn btn-primary" id="btnStartBreak">Start Break</button>
          <?php endif; ?>
        <?php else: ?>
        <h3>Right Aligned Navbar</h3>
        <p>The .navbar-right class is used to right-align navigation bar buttons.</p>
        <?php endif; ?>
      </div>
    </body>
</html>

<script type="text/javascript">
  
  $('#btnStartBreak').on('click',function() {
     jQuery.ajax({
        url: "<?php echo e(url('/start_break_time')); ?>",
        method: 'GET',
        success: function(result){
           location.reload();
        }});
  })


  $('#btnBack').on('click',function() {
     jQuery.ajax({
        url: "<?php echo e(url('/end_break_time')); ?>",
        method: 'GET',
        success: function(result){
           location.reload();
        }});
  })
</script>
<?php /**PATH D:\xampp\htdocs\PracticalTest\GreenitcoTest\resources\views/front/home.blade.php ENDPATH**/ ?>