 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Organizations</h3>
                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                     <a  type="btn btn-primary" href="<?php echo e(url('/')); ?>/employees/create">Add</a>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Organization</th>
                      <th>Email</th>
                      <th>Phone No.</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $arrdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($row->id); ?></td>
                      <td><?php echo e($row->first_name); ?> <?php echo e($row->last_name); ?></td>
                      <td><?php echo e($row->get_organization_name->name); ?></td>
                      <td><?php echo e($row->email); ?></td>
                      <td><?php echo e($row->phone_no); ?></td>
                      <td class="project-actions">
                          <a class="btn btn-info btn-sm" href="/employees/edit/<?=$row->id?>">
                              <i class="fas fa-pencil-alt">
                              </i>
                              Edit
                          </a>
                          <a class="btn btn-danger btn-sm" href="/employees/destroy/<?=$row->id?>">
                              <i class="fas fa-trash">
                              </i>
                              Delete
                          </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                 <?php echo e($arrdata->links('pagination.custom')); ?>

                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
      <div class="modal fade" id="modal-lg">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Create Organization</h4>
        
              <a  type="button" href="<?php echo e(url('/')); ?>/organization/create">Add</a>
            </div>
            <div class="modal-body">
                <div class="card card-primary">
                  <!-- form start -->
                  <form action="/organization/store" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter email">
                          <?php if($errors->has('name')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('name')); ?></span>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Password">
                        <?php if($errors->has('email')): ?>
                        <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Website</label>
                        <input type="text" class="form-control" id="website" name="website" placeholder="https://example.com">
                         <?php if($errors->has('website')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('website')); ?></span>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputFile">Logo</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" class="custom-file-input" id="logo" name="logo">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form>
                </div>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
    </section>
<!-- 
    <script type="text/javascript">
      function getOrganization() 
      {
         $.ajax({
               type:'get',
               url:'/organization/getOrganization',
               data:'_token = <?php echo csrf_token() ?>',
               success:function(data) {
                  $("#msg").html(data.msg);
               }
            });
      }
    </script> --><?php /**PATH D:\xampp\htdocs\kavitaLaravelTest\resources\views/employees/index.blade.php ENDPATH**/ ?>