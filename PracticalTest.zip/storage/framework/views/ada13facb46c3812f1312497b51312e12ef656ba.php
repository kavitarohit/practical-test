

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Create Employees Form</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Create Employees Form</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Create Employees</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
             <form action="<?php echo e(url('/')); ?>/employees/store" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                      <div class="form-group">
                        <label for="exampleInputEmail1">First Name</label>
                        <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First name">
                          <?php if($errors->has('first_name')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('first_name')); ?></span>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Last Name</label>
                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter last name">
                          <?php if($errors->has('last_name')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('last_name')); ?></span>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                          <label for="exampleSelectRounded0">Select Organization</label>
                          <select class="custom-select rounded-0" id="organization_id" name="organization_id">
                            <option value="">Select Organization</option>
                            <?php $__currentLoopData = $arrOrganization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?=$row['id']?>"><?php echo e($row['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <?php if($errors->has('organization_id')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('organization_id')); ?></span>
                          <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                        <?php if($errors->has('email')): ?>
                        <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">Phone No</label>
                        <input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone Number">
                         <?php if($errors->has('phone_no')): ?>
                          <span id="exampleInputEmail1-error" class="error invalid-feedback"><?php echo e($errors->first('phone_no')); ?></span>
                          <?php endif; ?>
                      </div>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form>
            </div>
            <!-- /.card -->

          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php /**PATH D:\xampp\htdocs\kavitaLaravelTest\resources\views/employees/create.blade.php ENDPATH**/ ?>