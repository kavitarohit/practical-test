<?php echo $__env->make('layouts.header',['title'=>$pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <!-- /.row -->
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Organizations</h3>
                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                     <a  type="btn btn-primary" href="<?php echo e(url('/')); ?>/employees/create">Add</a>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Organization</th>
                      <th>Email</th>
                      <th>Phone No.</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                  </tbody>
                </table>
                
                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

    <script type="text/javascript">
      function getOrganization() 
      {
         $.ajax({
               type:'get',
               url:'/api/getEmployees',
               data:'_token = <?php echo csrf_token() ?>',
               success:function(data) {
                  console.log(data);
               }
            });
      }
    </script><?php /**PATH D:\xampp\htdocs\kavitaLaravelTest\resources\views/employee.blade.php ENDPATH**/ ?>